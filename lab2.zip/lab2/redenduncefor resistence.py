from Bio import SeqIO
from Bio.Align import PairwiseAligner

input_file = "data/resistance_library_raw.fasta"
output_file = "data/resistance_library_nonredundant.fasta"

aligner = PairwiseAligner()
aligner.mode = "global"

identity_threshold = 0.90

sequences = list(SeqIO.parse(input_file, "fasta"))
unique_sequences = []

print("Starting redundancy removal for resistance library...\n")

for seq in sequences:

    is_redundant = False

    for uniq in unique_sequences:
        alignment = aligner.align(seq.seq, uniq.seq)[0]

        matches = sum(a == b for a, b in zip(str(seq.seq), str(uniq.seq)))
        identity = matches / max(len(seq.seq), len(uniq.seq))

        if identity >= identity_threshold:
            is_redundant = True
            break

    if not is_redundant:
        unique_sequences.append(seq)

SeqIO.write(unique_sequences, output_file, "fasta")

print("Original count:", len(sequences))
print("Non-redundant count:", len(unique_sequences))
