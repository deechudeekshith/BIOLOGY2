import pandas as pd
import torch
import numpy as np
from transformers import BertModel, BertTokenizer
from sklearn.decomposition import PCA
from tqdm import tqdm

# -----------------------------
# STEP 1: Load dataset
# -----------------------------
final_df = pd.read_csv("features/final_feature_dataset.csv")

print("Loaded dataset shape:", final_df.shape)

sequence_column = "sequence"  # Change if needed

# -----------------------------
# STEP 2: Load ProtBERT
# -----------------------------
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

tokenizer = BertTokenizer.from_pretrained("Rostlab/prot_bert", do_lower_case=False)
model = BertModel.from_pretrained("Rostlab/prot_bert")
model = model.to(device)
model.eval()

# -----------------------------
# STEP 3: Extract embeddings
# -----------------------------
all_embeddings = []

for seq in tqdm(final_df[sequence_column]):

    # Add space between amino acids
    seq = " ".join(list(seq))

    inputs = tokenizer(seq, return_tensors="pt", truncation=True)
    inputs = {key: val.to(device) for key, val in inputs.items()}

    with torch.no_grad():
        outputs = model(**inputs)

    # Mean pooling across sequence length
    embedding = outputs.last_hidden_state.mean(dim=1)

    all_embeddings.append(embedding.cpu().numpy().flatten())

all_embeddings = np.array(all_embeddings)

print("Raw BERT embedding shape:", all_embeddings.shape)
# Expected: (617, 1024)

# -----------------------------
# STEP 4: PCA → 20 Important Features
# -----------------------------
pca = PCA(n_components=20)
reduced_embeddings = pca.fit_transform(all_embeddings)

print("Reduced embedding shape:", reduced_embeddings.shape)
# Expected: (617, 20)

# Show how much variance is preserved
print("Total Explained Variance:",
      np.sum(pca.explained_variance_ratio_))

# -----------------------------
# STEP 5: Create dataframe
# -----------------------------
bert_feature_names = [f"bert_pca_{i+1}" for i in range(20)]
bert_df = pd.DataFrame(reduced_embeddings, columns=bert_feature_names)

# -----------------------------
# STEP 6: Merge with original features
# -----------------------------
enhanced_df = pd.concat(
    [final_df.reset_index(drop=True),
     bert_df.reset_index(drop=True)],
    axis=1
)

print("Final dataset shape:", enhanced_df.shape)

# -----------------------------
# STEP 7: Save new dataset
# -----------------------------
enhanced_df.to_csv("features/final_dataset_with_bert_20.csv", index=False)

print("✅ Final dataset with 20 BERT features saved successfully.")