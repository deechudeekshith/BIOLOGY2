from Bio import SeqIO
from Bio.SeqUtils.ProtParam import ProteinAnalysis
import pandas as pd
import os
import re

# Create features folder if not exists
os.makedirs("features", exist_ok=True)

def clean_sequence(seq):
    """
    Remove all invalid amino acids.
    Keep only standard 20 amino acids.
    """
    return re.sub('[^ACDEFGHIKLMNPQRSTVWY]', '', str(seq))


def extract_features(input_file, output_file):

    data = []

    print(f"\nProcessing: {input_file}")

    for record in SeqIO.parse(input_file, "fasta"):
        
        # Clean sequence
        seq = clean_sequence(record.seq)

        # Skip empty sequences after cleaning
        if len(seq) == 0:
            continue

        try:
            analysis = ProteinAnalysis(seq)

            length = len(seq)
            mw = analysis.molecular_weight()
            aromaticity = analysis.aromaticity()
            instability = analysis.instability_index()
            gravy = analysis.gravy()
            isoelectric = analysis.isoelectric_point()

            data.append([
                record.id,
                length,
                mw,
                aromaticity,
                instability,
                gravy,
                isoelectric
            ])

        except Exception as e:
            print(f"Skipped {record.id} due to error: {e}")

    df = pd.DataFrame(data, columns=[
        "protein_id",
        "length",
        "molecular_weight",
        "aromaticity",
        "instability_index",
        "gravy",
        "isoelectric_point"
    ])

    df.to_csv(output_file, index=False)

    print(f"Saved features to: {output_file}")
    print(f"Total sequences processed: {len(df)}")


# 🔹 RUN FOR ALL THREE DATASETS

extract_features(
    "data/query_proteins_nonredundant.fasta",
    "features/query_sequence_features.csv"
)

extract_features(
    "data/target_wildtype_nonredundant.fasta",
    "features/wildtype_sequence_features.csv"
)

extract_features(
    "data/resistance_library_nonredundant.fasta",
    "features/resistance_sequence_features.csv"
)

print("\nAll sequence feature extraction completed successfully.")