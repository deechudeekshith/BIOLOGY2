from Bio import SeqIO
from Bio.Align import PairwiseAligner
import pandas as pd

query_file = "data/query_proteins_nonredundant.fasta"
wild_file = "data/target_wildtype_nonredundant.fasta"
res_file = "data/resistance_library_nonredundant.fasta"

aligner = PairwiseAligner()
aligner.mode = "global"

query_sequences = list(SeqIO.parse(query_file, "fasta"))
wild_sequences = list(SeqIO.parse(wild_file, "fasta"))
res_sequences = list(SeqIO.parse(res_file, "fasta"))

data = []

print("Starting alignment feature extraction...\n")

for query in query_sequences:

    best_wild_identity = 0
    best_res_identity = 0

    for wt in wild_sequences:
        matches = sum(a == b for a, b in zip(str(query.seq), str(wt.seq)))
        identity = matches / max(len(query.seq), len(wt.seq))
        if identity > best_wild_identity:
            best_wild_identity = identity

    for res in res_sequences:
        matches = sum(a == b for a, b in zip(str(query.seq), str(res.seq)))
        identity = matches / max(len(query.seq), len(res.seq))
        if identity > best_res_identity:
            best_res_identity = identity

    data.append([
        query.id,
        best_wild_identity,
        best_res_identity,
        best_res_identity - best_wild_identity
    ])

df = pd.DataFrame(data, columns=[
    "protein_id",
    "wild_identity",
    "res_identity",
    "identity_difference"
])

df.to_csv("features/query_alignment_vs_wild&resistence_features.csv", index=False)

print("\nAlignment feature extraction complete.")