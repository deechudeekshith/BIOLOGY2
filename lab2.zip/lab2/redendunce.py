from Bio import SeqIO
from Bio.Align import PairwiseAligner
import os

input_file = "data/query_proteins_raw.fasta"
output_file = "data/query_proteins_nonredundant.fasta"

aligner = PairwiseAligner()
aligner.mode = 'global'

sequences = list(SeqIO.parse(input_file, "fasta"))
unique_sequences = []

identity_threshold = 0.90

print("Starting redundancy removal...")

for seq in sequences:
    is_redundant = False
    
    for uniq in unique_sequences:
        score = aligner.score(seq.seq, uniq.seq)
        max_len = max(len(seq.seq), len(uniq.seq))
        identity = score / max_len
        
        if identity >= identity_threshold:
            is_redundant = True
            break
    
    if not is_redundant:
        unique_sequences.append(seq)

SeqIO.write(unique_sequences, output_file, "fasta")

print("Original count:", len(sequences))
print("Non-redundant count:", len(unique_sequences))
