import pandas as pd

# Step 1: Load the datasets
seq_df = pd.read_csv("features/query_sequence_features.csv")
align_df = pd.read_csv("features/query_alignment_vs_wild&resistence_features.csv")

# Step 2: Merge on protein_id
final_df = pd.merge(seq_df, align_df, on="protein_id")

# Step 3: Save merged dataset
final_df.to_csv("features/final_feature_dataset.csv", index=False)

# Step 4: Print basic information
print("Final feature dataset created.")
print("Shape:", final_df.shape)

# Step 5: Print all feature names
print("\nFeature Names:")
for col in final_df.columns:
    print(col)

# Step 6: Print data types
print("\nData Types:")
print(final_df.dtypes)

# Step 7: Print summary statistics (numeric columns only)
print("\nStatistical Summary:")
print(final_df.describe())

# Step 8 (Optional but very useful): Check for missing values
print("\nMissing Values:")
print(final_df.isnull().sum())