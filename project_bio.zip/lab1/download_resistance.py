from Bio import Entrez, SeqIO
import time
import os

Entrez.email = "your_email@example.com"

os.makedirs("data", exist_ok=True)

output_file = "data/resistance_library_raw.fasta"

# Single combined resistance query
search_term = '''
(
"TEM beta-lactamase"[Protein name] OR
"SHV beta-lactamase"[Protein name] OR
"CTX-M beta-lactamase"[Protein name] OR
"OXA beta-lactamase"[Protein name] OR
"AmpC beta-lactamase"[Protein name] OR
"aminoglycoside acetyltransferase"[Protein name] OR
"aminoglycoside phosphotransferase"[Protein name] OR
"TetM"[Protein name] OR
"TetA"[Protein name] OR
"ErmB methyltransferase"[Protein name] OR
"AcrB"[Protein name] OR
"MexB"[Protein name] OR
"NorA"[Protein name]
)
AND bacteria[Organism]
NOT partial
'''

print("Searching resistance proteins...\n")

handle = Entrez.esearch(
    db="protein",
    term=search_term,
    retmax=1200
)

record = Entrez.read(handle)

id_list = record["IdList"]
count = int(record["Count"])

print(f"Total sequences found: {count}")
print(f"IDs retrieved: {len(id_list)}")

batch_size = 500

with open(output_file, "w") as out_handle:
    for start in range(0, len(id_list), batch_size):
        end = min(start + batch_size, len(id_list))
        print(f"Downloading records {start} to {end}...")

        fetch_handle = Entrez.efetch(
            db="protein",
            id=id_list[start:end],
            rettype="fasta",
            retmode="text"
        )

        sequences = list(SeqIO.parse(fetch_handle, "fasta"))
        SeqIO.write(sequences, out_handle, "fasta")

        time.sleep(0.5)

print("\nResistance library download complete.")
