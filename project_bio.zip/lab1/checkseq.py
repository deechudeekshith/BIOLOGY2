from Bio import SeqIO

count = len(list(SeqIO.parse("data/query_proteins_raw.fasta", "fasta")))
print("Total sequences_for quary in raw dataset:", count)

count = len(list(SeqIO.parse("data/query_proteins_nonredundant.fasta", "fasta")))
print("Total sequences in non-redundant dataset:", count)

count = len(list(SeqIO.parse( "data/resistance_library_raw.fasta", "fasta")))
print("Total sequences_for resistence in raw dataset:", count)

count = len(list(SeqIO.parse("data/resistance_library_nonredundant.fasta", "fasta")))
print("Total sequences in non-redundant dataset:", count)

count = len(list(SeqIO.parse( "data/target_wildtype_raw.fasta", "fasta")))
print("Total sequences_for target wildtype in raw dataset:", count)

count = len(list(SeqIO.parse("data/target_wildtype_nonredundant.fasta", "fasta")))
print("Total sequences in non-redundant dataset:", count)



