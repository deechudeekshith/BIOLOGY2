from Bio import Entrez
import time

# REQUIRED
Entrez.email = "your_email@example.com"

# -----------------------------
# Target proteins (expanded)
# -----------------------------
proteins = [
    "DNA gyrase subunit A",
    "DNA gyrase subunit B",
    "Topoisomerase IV subunit A",
    "Topoisomerase IV subunit B",
    "RNA polymerase beta subunit",
    "Penicillin-binding protein 1",
    "Penicillin-binding protein 2",
    "Penicillin-binding protein 3",
    "Ribosomal protein S12",
    "50S ribosomal protein L4",
    "50S ribosomal protein L22",
    "Dihydrofolate reductase",
    "Dihydropteroate synthase"
]

# -----------------------------
# Important bacterial species
# -----------------------------
species_list = [
    "Escherichia coli",
    "Klebsiella pneumoniae",
    "Staphylococcus aureus",
    "Pseudomonas aeruginosa",
    "Acinetobacter baumannii",
    "Salmonella enterica",
    "Enterococcus faecium"
]

output_file = "target_wildtype.fasta"

print("Starting download...\n")

for protein in proteins:
    for species in species_list:
        
        search_term = f"{protein} {species} NOT partial"
        print(f"Searching: {search_term}")
        
        try:
            handle = Entrez.esearch(
                db="protein",
                term=search_term,
                retmax=1  # 3 per combination (safe)
            )
            record = Entrez.read(handle)
            id_list = record["IdList"]
            
            if id_list:
                fetch = Entrez.efetch(
                    db="protein",
                    id=id_list,
                    rettype="fasta",
                    retmode="text"
                )
                data = fetch.read()
                
                with open(output_file, "a") as f:
                    f.write(data)
                
                print(f"Downloaded {len(id_list)} sequences.\n")
            else:
                print("No results found.\n")
            
            time.sleep(1)  # NCBI safe delay
        
        except Exception as e:
            print(f"Error occurred: {e}\n")

print("All target wildtype downloads complete.")
