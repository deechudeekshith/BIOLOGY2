from Bio import SeqIO
from Bio.Align import PairwiseAligner
import pandas as pd

input_file = "data/target_wildtype_nonredundant.fasta"

sequences = list(SeqIO.parse(input_file, "fasta"))

reference = sequences[0]

aligner = PairwiseAligner()
aligner.mode = 'global'

results = []

print("Aligning all sequences to reference...\n")

for seq in sequences[1:]:

    alignment = aligner.align(reference.seq, seq.seq)[0]

    matches = sum(a == b for a, b in zip(str(reference.seq), str(seq.seq)))
    identity = matches / len(reference.seq) * 100

    results.append([seq.id, identity])

    print(f"{seq.id} -> {round(identity,2)}%")

df = pd.DataFrame(results, columns=["Sequence_ID", "Identity_%"])
df.to_csv("alignment_identity_scores_for target.csv", index=False)

print("\nAlignment complete.")
